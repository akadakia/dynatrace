import os
import subprocess
import sys
from typing import List, Dict, Optional
import logging
from datetime import timedelta
import time

import psutil

default_log = logging.getLogger(__name__)


class ProcessController:
    def __init__(self, log=default_log):
        self.log = log

    def start_process(self, cmd, env: Optional[Dict[str, str]] = None) -> int:
        self.log.info(f"Attempting to execute the command '{cmd[0]}'")
        if sys.platform == "win32":
            p = subprocess.Popen(cmd, close_fds=True, stdout=None, stdin=None, shell=False, env=env, creationflags=0x00000008)
        else:
            p = subprocess.Popen(cmd, close_fds=True, stdout=None, stdin=None, shell=False, env=env)
        self.log.info(f"Successfully started the process, PID: {p.pid}")
        return p.pid

    def get_processes(self, name_filter: str, contains: bool = False) -> List[psutil.Process]:
        """
        Returns the list of process that match the name_filter string exactly
        :param name_filter: The name of the process
        :param contains: Match names that contain the string instead (DANGEROUS)
        :return: A list of psutil.Process instances
        """
        process_list = []
        for p in psutil.process_iter(attrs=["name", "cmdline"], ad_value="unknow"):
            try:
                if contains:
                    full_cmd = " ".join(p.cmdline())
                    if name_filter.lower() in full_cmd.lower():
                        self.log.info(f"Found process '{name_filter}': {p}")
                        process_list.append(p)
                else:
                    if p.name() == name_filter:
                        self.log.info(f"Found process '{name_filter}': {p}")
                        process_list.append(p)
            except psutil.AccessDenied:
                continue
        return process_list

    def get_process_by_pids(self, pids: List[int]):
        running_pids = []
        for p in psutil.process_iter():
            if p.pid in pids:
                self.log.info(f"Found process {p}")
                running_pids.append(p)
        return running_pids

    def kill_pid(self, pid: int):
        processes = self.get_process_by_pids([pid])
        for p in processes:
            self.kill_process(p)

    def kill_process(self, process: psutil.Process) -> bool:

        self.log.info(f"Attempting to cleanly terminate '{process}'")
        try:
            process.terminate()
            gone, alive = psutil.wait_procs([process], timeout=10)
        except psutil.AccessDenied:
            self.log.error(f"Could not kill {process}. Is it running as a different user than {os.getlogin()}?")
            return False
        if alive:
            try:
                # If the process is alive after 10 seconds, SIGKILL
                self.log.info(f"Attempting to forcefully terminate '{process}'")
                process.kill()
            except psutil.NoSuchProcess:
                pass
        gone, alive = psutil.wait_procs([process], timeout=10)
        if alive:
            # If we get here something is wrong, we cannot kill the process
            self.log.error(f"Could not kill the process '{process}'")
            return False
        else:
            self.log.info(f"Terminated the process '{process}'")
            return True

    def kill_processes(self, name_filter: str, contains=False):
        """
        Kills all process that match the name_filter string exactly.
        :param name_filter: Process name to kill
        :param contains: Match process where the name_filter is contained in the entire command line
        :return: None
        """
        for process in self.get_processes(name_filter, contains):
            self.kill_process(process)

    def kill_long_running_processes(self, pids: List[int], time_threshold: timedelta) -> List[int]:
        kept_alive: List[int] = []
        now = time.time()
        for process in self.get_process_by_pids(pids):
            time_running = now - process.create_time()
            if time_running > time_threshold.total_seconds():
                self.log.info(f"Killing process {process} because it has been running for more than {time_threshold} ({timedelta(seconds=time_running)})")
                self.kill_process(process)
            else:
                kept_alive.append(process.pid)

        return kept_alive
