import atexit
import tempfile
from pathlib import Path
import os

from ruxit.api.base_plugin import RemoteBasePlugin
from ruxit.api.exceptions import ConfigException

from log_proxy import LogProxy
from process_controller import ProcessController

JAR_NAME = "dynatrace-salesforce-rum-1.4.3.jar"
CURRENT_FILE_PATH = os.path.dirname(os.path.realpath(__file__))


class SalesforceEventStream(RemoteBasePlugin):
    def initialize(self, **kwargs):
        self.validate_parameters()
        self.process_controller = ProcessController(log=self.logger)

        tmp_dir = f"{tempfile.gettempdir()}/dynatrace-salesforce-connector/{self.activation.entity_id}"
        self.log_proxy = LogProxy(Path(f"{tmp_dir}/dynatrace-salesforce-connector.log"), Path(f"{tmp_dir}/log_cache.json"))
        self.command_line = f"{JAR_NAME} --endpoint {self.activation.entity_id}"

        # First, kill any running salesforce connector processes
        self.process_controller.kill_processes(self.command_line, contains=True)

        # Then, start the connector process
        self.start_connector()

        # When we are killed, also kill the java process(es)
        atexit.register(self.process_controller.kill_processes, self.command_line, contains=True)

    def validate_parameters(self):

        # Need username
        if not self.config.get("salesforce_username"):
            raise ConfigException("Salesforce username is always required")

        # Need key and url if using certificate
        if self.config.get("salesforce_client_certificate_chain") and (
            not self.config.get("salesforce_url") or not self.config.get("salesforce_client_certificate_key")
        ):
            raise ConfigException("When using a certificate chain, both the instance url and the certificate key need to be provided")

        # Need certificate and url if using key
        if self.config.get("salesforce_client_certificate_key") and (
            not self.config.get("salesforce_url") or not self.config.get("salesforce_client_certificate_chain")
        ):
            raise ConfigException("When using a certificate key, both the instance url and the certificate chain need to be provided")

        # Need url if using certificate and key
        if (
            self.config.get("salesforce_client_certificate_key")
            and self.config.get("salesforce_client_certificate_chain")
            and not self.config.get("salesforce_url")
        ):
            raise ConfigException("A salesforce instance url is required when using certificate authentication")

        # Can only use token OR certificate, not both
        if self.config.get("salesforce_client_certificate_chain") and self.config.get("salesforce_security_token"):
            raise ConfigException("A security token must not be supplied if mutual certificates, and vice versa")

        if self.config.get("salesforce_authentication_method") == "Connected App":
            if (
                not self.config.get("salesforce_consumer_key")
                or not self.config.get("salesforce_audience")
                or not self.config.get("salesforce_keystore_location")
                or not self.config.get("salesforce_keystore_password")
                or not self.config.get("salesforce_key_alias")
                or not self.config.get("salesforce_key_password")
            ):
                raise ConfigException("Need to fill all Connected App parameters")

    def close(self, **kwargs):
        self.process_controller.kill_processes(self.command_line, contains=True)

    def query(self, **kwargs):
        self.ensure_connector_running()

        group = self.topology_builder.create_group("Salesforce Connector", "Salesforce Connector")
        device = group.create_device(f"Salesforce Connector ({self.config.get('openkit_application_id')})")

        need_restart = False
        # Add the connector logs to the extension logs
        for line in self.log_proxy.get_lines_from_file():
            self.logger.info(f"dynatrace-salesforce-connector - {line}")
            if " WARN " in line:
                device.report_custom_info_event(line, "Received a warning from the salesforce connector")
            if " ERROR " in line or " FATAL " in line:
                need_restart = True
                device.report_error_event(line, "Received an error from the salesforce connector")

        if need_restart:
            self.restart_connector()

    def ensure_connector_running(self):
        # First, check if the process is running already
        number_of_running_processes = self.process_controller.get_processes(self.command_line, contains=True)
        if len(number_of_running_processes) == 0:
            # No running processes! Lets start it!
            self.logger.warning("There are no connector processes running, starting it")
            self.start_connector()

        # Check if we have more than 1 running processes as well, this should not happen
        elif len(number_of_running_processes) > 1:
            self.logger.error("Found more than one running process! This should never happen")
            self.process_controller.kill_processes(self.command_line, contains=True)
            self.start_connector()

    def restart_connector(self):
        self.logger.info(f"Restarting collector because of ERRORs detected")
        self.process_controller.kill_processes(self.command_line, contains=True)
        self.start_connector()

    def start_connector(self):
        java_path = find_java_bin()
        self.logger.info(f"Using java: '{java_path}'")

        jar_path = os.path.join(CURRENT_FILE_PATH, "bin", JAR_NAME)
        cmd = [java_path, "-jar", jar_path, "--endpoint", f"{self.activation.entity_id}"]

        # Add proxy parameters if necessary
        proxy_address = self.config.get("proxy_address")
        if proxy_address:
            protocol, address = proxy_address.split("://")
            host, port = address.split(":")

            proxy_params = [f"-Dhttps.proxyHost={host}", "-Dhttps.nonProxyHosts=localhost|127.0.0.1"]

            if port:
                proxy_params.append(f"-Dhttps.proxyPort={port}")
            if self.config.get("proxy_username"):
                proxy_params.append(f"-Dhttps.proxyUser={self.config.get('proxy_username')}")

            log_friendly_params = proxy_params.copy()
            if self.config.get("proxy_password"):
                log_friendly_params.append(f"-Dhttps.proxyPassword={'*' * len(self.config.get('proxy_password'))}")
                proxy_params.append(f"-Dhttps.proxyPassword={self.config.get('proxy_password')}")

            self.logger.info(f"Adding extra proxy parameters: {' '.join(log_friendly_params)}")
            cmd[1:1] = proxy_params

        auth_method = "CONNECTED_APP" if self.config.get("salesforce_authentication_method") == "Connected App" else "USERNAME_PASSWORD"
        env_extra = {
            "DYNATRACE_BEACON_URL": self.config.get("openkit_beacon_url"),
            "DYNATRACE_APPLICATION_ID": self.config.get("openkit_application_id"),
            "SALESFORCE_USERNAME": self.config.get("salesforce_username"),
            "SALESFORCE_PASSWORD": f"{self.config.get('salesforce_password')}{self.config.get('salesforce_security_token')}",
            "DYNATRACE_CAPTURE_USER_DETAILS": str(self.config.get("capture_user_details")),
            "DYNATRACE_LOG_LEVEL": self.config.get("log_level"),
            "DYNATRACE_MAX_SESSION_AGE_MINUTES": str(self.config.get("max_session_age_minutes")),
            "DYNATRACE_CAPTURE_LIGHTNING_URI": str(self.config.get("capture_lightning_uri")),
            "DYNATRACE_CAPTURE_API": str(self.config.get("capture_api")),
            "DYNATRACE_CAPTURE_LISTVIEW": str(self.config.get("capture_listview")),
            "DYNATRACE_CAPTURE_URI": str(self.config.get("capture_uri")),
            "DYNATRACE_CAPTURE_REPORT": str(self.config.get("capture_report")),
            "DYNATRACE_ENDPOINT_ID": str(self.activation.entity_id),
            "SALESFORCE_AUTHENTICATION_METHOD": auth_method,
            "SALESFORCE_CONSUMER_KEY": self.config.get("salesforce_consumer_key"),
            "SALESFORCE_AUDIENCE": self.config.get("salesforce_audience"),
            "SALESFORCE_KEYSTORE_LOCATION": self.config.get("salesforce_keystore_location"),
            "SALESFORCE_KEYSTORE_PASSWORD": self.config.get("salesforce_keystore_password"),
            "SALESFORCE_KEY_ALIAS": self.config.get("salesforce_key_alias"),
            "SALESFORCE_KEY_PASSWORD": self.config.get("salesforce_key_password"),
            "SALESFORCE_URL": self.config.get("salesforce_url") if self.config.get("salesforce_url") else "https://login.salesforce.com",
        }
        if self.config.get("salesforce_client_certificate_chain"):
            env_extra.update(
                {
                    "SALESFORCE_CLIENT_CERTIFICATE_CHAIN": self.config.get("salesforce_client_certificate_chain"),
                    "SALESFORCE_CLIENT_CERTIFICATE_KEY": self.config.get("salesforce_client_certificate_key"),
                }
            )

        env = os.environ.copy()
        env.update(env_extra)

        excluded_keys = ["SALESFORCE_PASSWORD"]
        log_env = {key: env_extra[key] for key in set(list(env_extra.keys())) - set(excluded_keys)}

        self.logger.info(f"Passing environment variables: {log_env}")
        self.process_controller.start_process(cmd, env)


def find_java_bin():
    locations = [
        f"../../../gateway/jre/bin/java{'.exe' if os.name == 'nt' else ''}",
        "/opt/dynatrace/gateway/jre/bin/java",
    ]

    for location in locations:
        if os.path.exists(location):
            return location

    if os.environ.get("GATEWAY_HOME", False):
        return f"{os.environ.get('GATEWAY_HOME')}/jre/bin/java"

    return "java"
